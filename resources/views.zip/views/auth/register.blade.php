@extends('layouts.Frontend')
@section('content')
<?php
$UserId = $BusinessName = old('name'); $ShopNumber = old('shop_number');$Description = old('description');$Profession = old('profession');$Email = old('email');$LocationAddress = old('location_address');$Building = old('building');$PhoneNumber = old('phone_number');$WebsiteFacebookPage = old('website_facebook_page'); 
$BusinessLogo = "";
$RegisterUrl = route('register');
if(isset($GetUserProfile) && !$GetUserProfile->isEmpty())
{
  //print_r($GetUserProfile);
  $UserId = $GetUserProfile[0]->id;
  $BusinessLogo = $GetUserProfile[0]->business_logo;
  $BusinessName = $GetUserProfile[0]->name;
  $ShopNumber = $GetUserProfile[0]->shop_number;
  $Profession = $GetUserProfile[0]->profession;
  $Email = $GetUserProfile[0]->email;
  $LocationAddress = $GetUserProfile[0]->location_address;
  $Building = $GetUserProfile[0]->building;
  $PhoneNumber = $GetUserProfile[0]->phone_number;
  $WebsiteFacebookPage = $GetUserProfile[0]->website_facebook_page;
  $Description = $GetUserProfile[0]->description;
  $RegisterUrl = route('ProfileUpdate');
}
?>
@if(Auth::check())
<script type="text/javascript">
var DeleteBusinessLogo = "{{ route('DeleteBusinessLogo') }}";  //Delete Business Logo ajax url path 
</script>
@endif
<div class="full-vc-container">
    <div class="container">
      <div class="box-sign-up">
        <div class="sing-uo-page col-md-8">
          @if(Session::has('message'))
<p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
@endif
<?php
if(Session::has('message'))
{
  Session::flash('alert-class','');
  Session::flash('message', "");
}
?>
          <div class="heading-sign text-center">
            <h3>
            @if($UserId>0)
              {{ $VendorName }}
            @else
              SIGN UP HUSTLE YAKO,BIASHARA YAKO NA PIA TALANTA.
            @endif
            </h3>
          </div>
          <div class="sign-colm">
            <form action="{{ $RegisterUrl }}" class="sign-form" method="post" enctype="multipart/form-data" id="">
              @csrf
              @if($UserId>0)
                <input type="hidden" name="UserId" value="{{ $UserId }}"> 
              @endif
              <input type="hidden" name="user_type" value="2"><!-- 2 for vendor -->
              <div class="form-group">
                <div class="col-md-4 label-col-s">
                  <label>Business Name *</label>
                </div>
                <div class="col-md-8">
                  <div class="name-req-f"><input class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" type="text" name="name" placeholder="Shop Name" value="{{ $BusinessName }}">
                @if ($errors->has('name'))
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('name') }}</strong>
                  </span>
                @endif
                </div>
                </div>
                </div>
                <div class="form-group">
                <div class="col-md-4 label-col-s">
                  <label>Shop No. *</label>
                </div>
                <div class="col-md-8">
                  <input class="form-control" type="text" name="shop_number" placeholder="Shop No." value="{{ $ShopNumber }}">
                @if ($errors->has('shop_number'))
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('shop_number') }}</strong>
                  </span>
                @endif
                </div>  
              </div>
                <div class="form-group">
                <div class="col-md-4 label-col-s">
                  <label>Profession *</label>
                </div>
                <div class="col-md-8">
                  <div class="name-req-f"><input class="form-control{{ $errors->has('profession') ? ' is-invalid' : '' }}" type="text" name="profession" placeholder="Profession" value="{{ $Profession }}">
                @if ($errors->has('profession'))
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('profession') }}</strong>
                  </span>
                @endif
                </div>
                </div>
                </div>
              <div class="form-group">
                <div class="col-md-4 label-col-s">
                  <label>Email *</label>
                </div>
                <div class="col-md-8">
                  <input class="form-control" type="text" name="email" placeholder="Email" value="{{ $Email }}">
                @if ($errors->has('email'))
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('email') }}</strong>
                  </span>
                @endif
                </div>

              </div>
              <div class="form-group">
                <div class="col-md-4 label-col-s">
                  <label>Location/address *</label>
                </div>
                <div class="col-md-8">
                  <div class="name-req-f"><input class="form-control" type="text" name="location_address" placeholder="Location/address" value="{{ $LocationAddress }}">
                  @if ($errors->has('location_address'))
                    <span class="invalid-feedback" role="alert">
                      <strong>{{ $errors->first('location_address') }}</strong>
                    </span>
                  @endif
                  </div>
                </div>
              </div>
              <div class="form-group">
                <div class="col-md-4 label-col-s">
                  <label>Building *</label>
                </div>
                <div class="col-md-8">
                  <input class="form-control" type="text" name="building" placeholder="Building" value="{{ $Building }}">
                @if ($errors->has('building'))
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('building') }}</strong>
                  </span>
                @endif
                </div>
              </div>
              <div class="form-group">
                <div class="col-md-4 label-col-s">
                  <label>Phone Number *</label>
                </div>
                <div class="col-md-8">
                  <input class="form-control" type="phone_number" name="phone_number" placeholder="Phone Number" value="{{ $PhoneNumber }}">
                @if ($errors->has('phone_number'))
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('phone_number') }}</strong>
                  </span>
                @endif
                </div>

              </div>
              <div class="form-group">
                <div class="col-md-4 label-col-s">
                  <label>Business Logo *</label>
                </div>
                <div class="col-md-8 choose-filel">
                  <div class="logo-fillup" id="business_logo">
                    @if($BusinessLogo!="")
                       <img id='business_logo_preview' src='{{ asset("public/images/business_logo/".$BusinessLogo) }}' width='100' height='100'/>
                       @if(Auth::check() && $UserId==Auth()->user()->id)
                       <a href='#' class='remove_field' style='margin-left:10px;' BusinessLogoId="{{ Auth()->user()->id }}">Remove</a>
                       @endif
                    @endif
                  </div>
                  <div class="logo-company">
                    <input class="form-control business_logo" id="logocompany" type="file" name="business_logo" placeholder="">
                    @if(Auth::check() && $UserId==Auth()->user()->id || !Auth::check())
                      <span for="logocompany">Browse</span>
                    @endif
                  </div>
                </div>
              </div>
              <div class="form-group">
                <div class="col-md-4 label-col-s">
                  <label></label>
                </div>
                <div class="col-md-8">
              @if ($errors->has('business_logo'))
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('business_logo') }}</strong>
                  </span>
                @endif
                </div>
              </div>
              <!-- <div class="form-group">
                <div class="col-md-4 label-col-s">
                  <label>Gender</label>
                </div>
                <div class="col-md-8">
                  <div class="gender-f">
                    <span><input type="radio" name="gender" value="male" @if(old('gender')=='male') {{ 'checked' }} @endif> Male</span>
                    <span><input type="radio" name="gender" value="female" @if(old('gender')=='female') {{ 'checked' }} @endif> Female<br></span>
                  </div>
                </div>
              </div> -->
              <div class="form-group">
                <div class="col-md-4 label-col-s">
                  <label>Website/Facebook Page</label>
                </div>
                <div class="col-md-8">
                  <input class="form-control" type="url" name="website_facebook_page" placeholder="wwww.businesslink.com" value="{{ $WebsiteFacebookPage }}">
                @if ($errors->has('website_facebook_page'))
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('website_facebook_page') }}</strong>
                  </span>
                @endif
                </div>

              </div>
              <div class="form-group">
                <div class="col-md-4 label-col-s">
                  <label>Description of Business *</label>
                </div>
                <div class="col-md-8">
                  <textarea class="form-control" name="description">{{ $Description }}</textarea>
                @if ($errors->has('description'))
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('description') }}</strong>
                  </span>
                @endif
                </div>
              </div>
              @if(!auth::check())
              <div class="form-group">
                <div class="col-md-4 label-col-s">
                  <label>Password</label>
                </div>
                <div class="col-md-8">
                  <input class="form-control" type="password" name="password" placeholder="Password" autocomplete="false" value="">
                  <p>At least 8 Charecter</p>
                  @if ($errors->has('password'))
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('password') }}</strong>
                  </span>
                  @endif
                </div>
              </div>
              <div class="form-group">
                <div class="col-md-4 label-col-s">
                  <label>Confirm Password</label>
                </div>
                <div class="col-md-8">
                  <input class="form-control" type="password" name="password_confirmation" placeholder="Confirm Password">
                </div>
              </div>
              @endif
              <div class="form-group">
                <div class="col-md-4 label-col-s">
                </div>
                <div class="col-md-8">
                  @if(!auth::check())
                  <input class="inputcheck-filed" type="checkbox" name="terms_conditions" value="terms_conditions" @if(old('terms_conditions')=='terms_conditions') {{ 'checked' }} @endif>
                  <span>I have read and agree to the <a href="#">Terms & Conditions</a></span>
                  @if ($errors->has('terms_conditions'))
                  <br/>
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first('terms_conditions') }}</strong>
                  </span>
                  @endif
                  @endif
                  <div class="submit-sign">
                    @if((Auth::check() && $UserId==Auth()->user()->id) || !Auth::check())
                      <button type="submit">Submit</button>
                    @elseif(Auth::check() && $UserId!=Auth()->user()->id)
                      <?php
                        $VendorName = str_replace(' ', '-', Auth()->user()->name);
                      ?>
                      <span class="product-btn"><a href="{{ route('ProductManage',['VendorName'=>$VendorName,'VendorId'=>$UserId]) }}">View Shop</a></span>
                    @endif
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
        <div class="col-md-4 rigt-sgn-column" style="background-color: #f0f0f0;">
          <div class="nv-colum1">
            <span><img src="{{ asset('public/images/pictures.png') }}"></span>
            <h3>Post a Free Product</h3>
            <p>You can post your product item with TapanBuy today. It's free. Create an account to get started.</p>
          </div>
          <div class="nv-colum1">
            <span><img src="{{ asset('public/images/pencil.png') }}"></span>
            <h3>Create and Manage Items</h3>
            <p>All the items you create with us can be easily managed by you on a click of a button.</p>
          </div>
          <div class="nv-colum1">
            <span><img src="{{ asset('public/images/like.png') }}"></span>
            <h3>Advertise with us.</h3>
            <p>It is easy. Create an account and add your items, describing them. It's that simple.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
<script src="{{ asset('public/js/RegisterBusinessLogo.js') }}"></script>
@endsection