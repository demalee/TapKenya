<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Tanandbuydeals</title>

    <!-- css start -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="{{ asset('public/css/style.css') }}"> 
    <!-- css end -->
    <!-- javascript  library start-->
    <script  src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script  src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!-- javascript library end-->
    <script type="text/javascript">
     var Csrf ="{{ csrf_token() }}"; 
     var RouteName = "{{ Route::currentRouteName() }}";
     var ProductSearchHeaderAjax = "{{ Route('ProductSearchHeaderAjax') }}";

    </script>

    @if(Auth::check())
      <script type="text/javascript">
        var ProductAddAjax = "{{ route('ProductAdd') }}"; //Product Add Ajax Path Url
      </script>
    @endif
</head>
<body> 
    <?php
      //die();
    ?>
    <div id="app">
        <header>
    <nav class="navbar navbar-default" role="navigation">
      <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header row">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="{{ url('/') }}"><img src="{{ asset('public/images/logo.png') }}"></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <div class="col-sm-4 col-md-4">
              <form class="navbar-form" role="search">
              <div class="input-group search-group">
                  <div class="input-group-icon">
                      <span class="search-icon"><i class="glyphicon glyphicon-search"></i></span>
                  </div>
<input type="text" class="form-control" placeholder="Search" name="SearchHeader" id="SearchHeader">
 <div id="suggesstion-box" class="sugest-bx" style="display: none">
    <ul id="ProductList" class="sug-sub-bx">
    </ul>
 </div>
                  <div class="input-group-btn">
                      <button class="btn btn-default" type="submit">Search</button>
                  </div>
              </div>
              </form>
          </div>
          <ul class="nav navbar-nav navbar-right">
            <li class="menu-item-bar"><a href="{{ url('/') }}">Home</a></li>
            @guest
            <li class="menu-item-bar"><a href="{{ route('login') }}">Login</a></li>
            <li class="menu-item-bar"><a href="{{ route('register') }}">Sign Up</a></li>
            @else
            <li class="menu-item-bar"><a href="javascript:void(0)" data-toggle="modal" data-target="#paidad">Create paid ad</a></li>
            <li class="menu-item-bar"><a href="javascript:void(0)">Sell Something</a></li>
            <!-- <li class="notification menu-item-bar"><a href="#"><i class="fa fa-bell" aria-hidden="true"></i></a><span class="notifi-btn"><button type="button">99+</button></span></li> -->
            <li class="compass menu-item-bar"><a href="#"><img src="{{ asset('public//images/icons/compass.png') }}"></a></li>
            <li class="dropdown menu-item-bar">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-cog" aria-hidden="true"></i>{{ Auth()->user()->name }}<span class="caret"></span></a>
              <ul class="dropdown-menu">
                  <?php
                  $VendorName = str_replace(' ', '-', Auth()->user()->name);
                  ?>
                  <li><a href="{{ route('Myprofile',['VendorName'=>$VendorName]) }}">My Profile</a></li>
                  <li><a href="{{ route('ProductManage',['VendorName'=>$VendorName]) }}">Manage Product</a></li>
                  <li><a href="{{ route('EventAdd',['VendorName'=>$VendorName]) }}">Create Event</a></li>
                  <li><a href="{{ route('ProductManageRequest') }}">Manage Requests</a></li>
                  <li><a href="#">Post a Request</a></li>
                  <li><a href="#">Account Setting</a></li>
                  <li><a href="#">Help</a></li>
                  <li><a class="dropdown-item" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form></li>
              </ul>
            </li>
            @if(Auth()->user()->user_type==1)
            <li class="menu-item-bar"><a href="{{ route('AdminHome') }}">Admin Panel</a></li>
            @endif
            @endguest
          </ul>
        </div><!-- /.navbar-collapse -->
        </div>
    </nav>
    <div class="bottom-menu-category">
      <div class="container">
        <div class="col-md-12" style="padding: 0px;">
          <div class="header-btm clearfix">
            <input class="menu-btn" type="checkbox" id="menu-btn" />
            <label class="menu-icon" for="menu-btn"><span class="navicon"></span></label>
            <ul class="category-menu menu">
              @if(!$GetAllCategories->isEmpty())
                @foreach($GetAllCategories as $Category) 
                  <?php
                  $CategoryName = str_replace(' ', '-', $Category->category_name);
                  ?>
                  <li><a href="{{ route('CategoryVendor',['CategoryName'=>$CategoryName,'CategoryId'=>$Category->id]) }}">{{ $Category->category_name }}</a></li>
                @endforeach
              @endif
            </ul>
          </div>
        </div>
      </div>
    </div>
  </header>
        <main class="py-4">
            @yield('content')
        </main>
    </div>
    <script src="{{ asset('public/js/Common.js') }}"></script>
</body>
</html>
@if(Auth::check())
<!--------Start Modal Create Paid Ad ------------------>
<!-- Create Paid Ad Modal Start-->
  <div class="modal fade" id="paidad" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content model-edit-form">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Item for sale</h4>
        </div>
        <div class="modal-body">
          <div class="">
            <form id="ProductAdd" class="sign-form" method="post" enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="create_paid_ad" value="1">
        <div class="tab">
            <div class="form-sale">
              <input type="text" name="product_name" placeholder="What are you selling" value="">
            </div>
            <div class="form-sale">
              <input type="number" name="product_price" placeholder="Price" value="">
            </div>
            <div class="form-sale locationset-n">
              <span class="locationsell"><i class="fa fa-map-marker" aria-hidden="true"></i></span>
              <input type="text" name="product_city" placeholder="Indore, India" value="">
            </div>
            <div class="form-sale">
              <select name="category_id">
                  <option value="">Category</option>
                  @if(!$GetAllCategories->isEmpty())
                    @foreach($GetAllCategories as $Category)
                      <option value="{{ $Category->id }}" >{{ $Category->category_name }}</option>
                    @endforeach
                  @endif
              </select>
          </div>
          <div class="form-sale">
                   <input type="text" name="product_phone" placeholder="Phone No." value="">
          </div>
            <div class="form-group">
                <div class="disc-sale-f">
                    <input type="text" name="product_description" placeholder="Describe your item (optional)" value="">
                </div>
                <!-- <div class="">
                    <span class="multiple_images">
                        <div class="multiple-input">
                            <i class="fa fa-picture-o" aria-hidden="true"></i>
                         </div>
                        <input class="multiple-img-cont ProductFiles" type="file" name="product_images[]" multiple />
                        <label for='file-input'>+10 Photos</label>
                    </span>
                </div> -->
            </div>
        </div>
        <div class="row input_fields_container">
                <div class="row form-group">
                  <label for="product_images" class="col-md-3 col-form-label text-md-right"></label>
                  <div class="col-md-9">
                      <input name="product_images[]" type="file" id="product_images" class="file" />
                      <a href="#" class="remove_field" id="remove" style="margin-left:10px;display: none">Remove</a>
                  </div>
                </div>
                </div>
                <br/>
                <div class="form-group row">
                  <label for="add_more_button" class="col-md-4 col-form-label text-md-right"></label>
                  <button class="btn btn-sm btn-primary add_more_button" type="button">Add More Fields</button>
                </div>
        <div class="modal-footer" style="background-color: transparent;">
            <button type="submit" class="btn-post-s ProductAdd">Submit</button>
            <!-- <button type="button" id="prevBtn" onclick="nextPrev(-1)">Submit</button>
              <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button> -->
        </div>
        </form>
          </div>
        </div>
      </div>
    </div>
  </div>
 <!--------End Modal Create Paid Ad ------------------>
@endif