
<?php
function SingularPlural($number)
{
  if($number>1)
  {
    return "s";
  }
}
?>
@if(!$GetProductImages->isEmpty())
<?php 
$i=0;
?>
<div id="slide1" class="carousel slide text-center" data-ride="carousel" >
<div class="carousel-inner full-view-img" >
@foreach($GetProductImages as $ProductImage)
<div class="item @if($i==0) {{ 'active' }} @endif">
    <img class="full-resp" src="{{ asset('public/images/product_images/'.$ProductImage->product_image_name) }}">
    <br>
     <!--  -->
     
           
                  
</div>
<?php 
$i++;
?>
@endforeach

               

</div>
<br>

       <div class="contactno"><span class="contact-no-post"><a href="https://web.whatsapp.com"><small style="color: white">+254 706 244 585</small></a></span><span class="contact-no-post">Ksh 2500/-</span></div>

@if(count($GetProductImages)>1)
<a class="left carousel-control" href="#slide1" data-slide="prev">
<span class="glyphicon glyphicon-chevron-left"></span>
<span class="sr-only">Previous</span>
</a>
<a class="right carousel-control" href="#slide1" data-slide="next">
<span class="glyphicon glyphicon-chevron-right"></span>
<span class="sr-only">Next</span>
</a>
@endif
</div>
@endif
