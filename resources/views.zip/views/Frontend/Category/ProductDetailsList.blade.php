<?php
function SingularPlural($number)
{
  if($number>1)
  {
    return "s";
  }
}
            ?>
          @if(!$RecentProductDetailsList->isEmpty())
            @foreach($RecentProductDetailsList as $Product)
            <div class="post-us-vc ProductLikeUsersParent">
              <div class="full-post-page">
                <!-- <div class="post-menu-s">
                  @if(Auth::check())
                  <div class="dropdown">
                    <button class="btn dropdown-toggle" type="button" data-toggle="dropdown"><i class="fa fa-ellipsis-h" aria-hidden="true"></i></button>
                    <ul class="dropdown-menu">
                      @if(Auth::check() && Auth()->user()->user_type==1)
                      <?php $ProductName = str_replace(' ', '-', $Product->product_name); ?>
                      <li><a href="{{ route('ProductDelete',['ProductName'=>$ProductName,'ProductId'=>$Product->id]) }}" class="ProductDelete" ProductId="{{ $Product->id }}" onclick="return DeleteTest();">Delete Post</a></li>
                      @endif
                      <li><a href="javascript:void(0)" class="ClaimToRemovePost" ProductId="{{ $Product->id }}">Claim To Remove Post</a></li>
                      <li><a href="javascript:void(0)"class="ReportPictureAsYour" ProductId="{{ $Product->id }}">Report Picture As Your</a></li>
                    </ul>
                  </div>
                  @endif
                </div> -->
                <div class="post-us00">
                  <div class="user-img">
                    <?php 
                          $BusinessLogo = url('public/images/user_default_pic.jpg');
                       ?>
                       @if($Product->business_logo!="" && file_exists(public_path().'/images/business_logo/'.$Product->business_logo))         
                        <?php 
                          $BusinessLogo = url('public/images/business_logo/'.$Product->business_logo);
                        ?>
                       @endif
                    <img src="{{ $BusinessLogo }}">
                  </div>
                  <div class="user-name-time">
                    <?php
                  $CategoryName = str_replace(' ', '-', $Product->category_name);
                  $CategoryVendor = route('CategoryVendor',['CategoryName'=>$CategoryName,'CategoryId'=>$Product->CategoryId]);
                  ?>
                    <h4>
                      <!-- <a href="{{ $CategoryVendor }}" class="CategoryVendor"> --> 
                      <?php
                        $VendorName = str_replace(' ', '-', $Product->VendorName);
                      ?>
                      <a href="{{ route('Myprofile',['VendorName'=>$VendorName,'VendorId'=>$Product->vendor_id]) }}" class="CategoryVendor">
                      {{ $Product->VendorName }}
                      </a>
                     </h4>
                    <!-- <span class="post-hours">32 mins</span> -->
                  </div>
                </div>
                <div class="product-all-img">
                  <!-- <div class="contactno"><span class="contact-no-post">
                    +{{ $Product->product_phone }}</span><span class="contact-no-post">Ksh {{ $Product->product_price }}/-</span></div> -->
                  <a href="JavaScript:void(0);" class="SliderPopup" ProductId="{{ $Product->id }}">
                  <?php 
                      $ProductImages = explode(",",$Product->ProductImages);
                      $ProductImage1 = $ProductImage2 = $ProductImage3 = $ProductImage4 = $ProductImage5 = ""; 
                      $ProductImagesCount = count($ProductImages);
                      $SliderPopup='';
                      for ($i=0; $i <$ProductImagesCount ; $i++) 
                      { 
                         $ActiveClass = "";
                         if($i==0)
                         {
                           $ActiveClass = "active";
                           $ProductImage1 = $ProductImages[$i];
                         }
                         else if($i==1)
                         {
                           $ProductImage2 = $ProductImages[$i];
                         }
                         else if($i==2)
                         {
                           $ProductImage3 = $ProductImages[$i];
                         }
                         else if($i==3)
                         {
                           $ProductImage4 = $ProductImages[$i];
                         }
                         else if($i==4)
                         {
                           $ProductImage5 = $ProductImages[$i];
                         }
                         if($i+1==$ProductImagesCount)
                         {
                          break;
                         }
                      }
                      ?>
                    <div class="image-num1" style="@if($ProductImagesCount!=1) {{ 'display: none;' }} @endif">
                      <img src="{{ asset('public/images/product_images/'.$ProductImage1) }}">
                    </div>

                    <div class="image-num2" style="@if($ProductImagesCount!=2) {{ 'display: none;' }} @endif">
                      <div class="imgcount1">  
                        <img src="{{ asset('public/images/product_images/'.$ProductImage1) }}">
                      </div>
                      <div class="imgcount1">
                        <img src="{{ asset('public/images/product_images/'.$ProductImage2) }}">
                      </div>
                    </div>

                    <div class="image-num3" style="@if($ProductImagesCount!=3) {{ 'display: none;' }} @endif">
                      <div class="imgcount3">  
                        <img src="{{ asset('public/images/product_images/'.$ProductImage1) }}">
                      </div>
                      <div class="imgcount31">
                        <img src="{{ asset('public/images/product_images/'.$ProductImage2) }}">
                      </div>
                      <div class="imgcount31">
                        <img src="{{ asset('public/images/product_images/'.$ProductImage3) }}">
                      </div>
                    </div>

                    <div class="image-num4" style="@if($ProductImagesCount!=4) {{ 'display: none;' }} @endif">
                      <div class="imgcount4">  
                        <img src="{{ asset('public/images/product_images/'.$ProductImage1) }}">
                      </div>
                      <div class="imgcount41">
                        <img src="{{ asset('public/images/product_images/'.$ProductImage2) }}">
                      </div>
                      <div class="imgcount41">
                        <img src="{{ asset('public/images/product_images/'.$ProductImage3) }}">
                      </div>
                      <div class="imgcount41">
                        <img src="{{ asset('public/images/product_images/'.$ProductImage4) }}">
                      </div>
                    </div>
                    
                    <div class="image-num5" style="@if($ProductImagesCount!=5) {{ 'display: none;' }} @endif">
                      <div class="colum-divide1img">
                        <div class="imgcount5">  
                          <img src="{{ asset('public/images/product_images/'.$ProductImage1) }}">
                        </div>
                        <div class="imgcount5">
                          <img src="{{ asset('public/images/product_images/'.$ProductImage2) }}">
                        </div>
                      </div>
                      <div class="colum-divide1img">
                        <div class="imgcount51">
                          <img src="{{ asset('public/images/product_images/'.$ProductImage3) }}">
                        </div>
                        <div class="imgcount51">
                          <img src="{{ asset('public/images/product_images/'.$ProductImage4) }}">
                        </div>
                        <div class="imgcount51">
                          <img src="{{ asset('public/images/product_images/'.$ProductImage5) }}">
                        </div>
                      </div>
                    </div>

                    <div class="image-num5" style="@if($ProductImagesCount<6) {{ 'display: none;' }} @endif">
                      <div class="colum-divide1img">
                        <div class="imgcount5">  
                          <img src="{{ asset('public/images/product_images/'.$ProductImage1) }}">
                        </div>
                        <div class="imgcount5">
                          <img src="{{ asset('public/images/product_images/'.$ProductImage2) }}">
                        </div>
                      </div>
                      <div class="colum-divide1img">
                        <div class="imgcount51">
                          <img src="{{ asset('public/images/product_images/'.$ProductImage3) }}">
                        </div>
                        <div class="imgcount51">
                          <img src="{{ asset('public/images/product_images/'.$ProductImage4) }}">
                        </div>
                        <div class="imgcount51 addmore-num">
                          <img src="{{ asset('public/images/product_images/'.$ProductImage5) }}">
                          <span class="addm-img8">+{{ count($ProductImages) }}</span>
                        </div>
                      </div>
                    </div>
                  </a>
                </div>
                <div class="postl-v">
                 <center> <h2>{{ $Product->product_name }}</h2></center>
                  <div class="short-dics-post">
                    <p style="font-size: 16px;">{{ $Product->product_description }}</p>
                  </div>
                  <br>
                  <span class="price-post"><small style="color: black; font-size: 16px;"  >Price:Ksh {{ $Product->product_price }}/=</samll></span>
                  <!-- <span class="location-post"><i class="fa fa-map-marker" aria-hidden="true"></i> London</span> -->
                  
                  <div class="views-pst">
                    <!-- <span>2,800 Views</span> -->
                  </div>
                </div>
                <div class="likes-user">
                <div class="other-user-l" >
                  <!-- <span class="like-btn"><i class="fa fa-thumbs-up" aria-hidden="true"></i></span>
                  <span class="whislist-btn"><i class="fa fa-heart" aria-hidden="true"></i></span> -->
                  <span class="name-point ProductLikeUsers" id="ProductLikeUsers" >
                <?php 
                $ParaMeter = array();
                $ParaMeter["ProductId"] = $Product->id;
                $ProductLikeUsers = App\ProductLike::GetProductLikes($ParaMeter);
                if(!$ProductLikeUsers->isEmpty())
                {
                  $ProductLikeUsersArray = explode(",", $ProductLikeUsers[0]->ProductLikeUsers);
                  $ProductLikeUserCount = count($ProductLikeUsersArray);
                  if($ProductLikeUserCount>2)
                  {
                    $LikeMessage = "";
                    for ($i=0; $i < $ProductLikeUserCount; $i++) 
                    { 
                      if($i==2)
                      {
                        break;
                      }
                      if($i!=0)
                      {
                        //echo " , ";
                        $LikeMessage .= " , ";
                      }
                      $LikeMessage .= $ProductLikeUsersArray[$i];
                      $LikeMessage .=  " ";
                    }
                    $LikeMessage .=  $ProductLikeUserCount-2;
                    $LikeMessage .=  " other";
                    if($ProductLikeUserCount!=3)
                    {
                      $LikeMessage .=  "s";
                    }
                    //echo $LikeMessage;
                  }
                  else
                  {
                    //echo $ProductLikeUsers[0]->ProductLikeUsers; 
                  }
                }
                ?>
                  </span>
                </div>
                <div class="like-coment-fill clearfix" style="display: none;">
                  
                  <ul class="bottom-likes clearfix">
                    <li>
                      <a id="CreatePaidAdLike1" class="CreatePaidAdLike1" ProductId="{{ $Product->id }}">
                        <span>
                          <i class="fa fa-thumbs-o-up" aria-hidden="true"></i>
                        </span>
                        Like
                      </a>
                    </li>
                    <?php
                    //$ParaMeter["Limit"] = 3;
                    $GetProductComments = App\ProductComment::GetProductComments($ParaMeter);
                    ?>
                    <li><a href="#"><span><i class="fa fa-comments-o" aria-hidden="true"></i></span> 
                    <span id="ProductCommentCount1"><?php echo count($GetProductComments); ?></span> Comment</a></li>
                  </ul>
                </div>
                <div class="post_comment_write">
              <div class="adding-coment form-group">
                <?php 
                  $BusinessLogo = url('public/images/user_default_pic.jpg');
                ?>
                @if(Auth::check() && (Auth::user()->business_logo!="" && file_exists(public_path().'/images/business_logo/'.Auth::user()->business_logo)))
                      <?php 
                          $BusinessLogo = url('public/images/business_logo/'.Auth::user()->business_logo);
                        ?>
                      @endif
<!--                       <img class="user-coment-text" src="{{ $BusinessLogo }}" width="100px" height="100px">
 -->                      <!-- <div class="coment-field-text">
                        <input type="text" name="comments" class="comments form-control" placeholder="Write a comment..." ProductId="{{ $Product['id'] }}" value="">
                      </div> -->
                </div>
                    <div class="comnt-box_vei" id="ProductComments">
                    @if(!$GetProductComments->isEmpty())
                      <?php
                        $ViewMore = 0; 
                      ?>
                      @foreach($GetProductComments as $Comment) 
                      <?php 
                        $ViewMore++;
                      ?> 
               <!--  <div class="commet-veiw_userbl @if($ViewMore>3) {{ 'ViewMoreCommentHide' }} @endif" style="@if($ViewMore>3) {{ 'display: none' }} @endif">
                                  <?php 
                                      $BusinessLogo = url('public/images/user_default_pic.jpg');
                                   ?>
                                   @if($Comment["business_logo"]!="" && file_exists(public_path().'/images/business_logo/'.$Comment["business_logo"]))         
                                     <?php 
                                      $BusinessLogo = url('public/images/business_logo/'.$Comment["business_logo"]);
                                    ?>
                                   @endif
                                  <img class="comm-56" src="{{ $BusinessLogo }}" width="100px" height="100px">
                                  <div class="user_veiw-coment">
                                      <h6 class="usr_title-name">
                                        <?php
                                          $VendorName = str_replace(' ', '-', $Comment['name']);
                                        ?>
                                        <a href="{{ route('Myprofile',['VendorName'=>$VendorName,'VendorId'=>$Comment['vendor_id']]) }}"> {{ $Comment["name"] }} </a>
                                      </h6>
                                      <p> {{ $Comment["comment"] }} </p>
                                  </div>
                              </div> -->
                        @endforeach
                        @if($GetProductComments->count()>3)
                          <div class="commet-veiw_userbl ViewMoreCommentShow">
                            <span> View More </span> 
                          </div>
                        @endif
                    @endif
                    </div>
                </div>
              </div>
              </div>

                <?php
$date1 = strtotime($Product->created_at);  
$date2 = strtotime(date("Y-m-d H:i:s"));  
$diff = abs($date2 - $date1);  
$years = floor($diff / (365*60*60*24));   
$months = floor(($diff - $years * 365*60*60*24)/(30*60*60*24));  
$days = floor(($diff-$years*365*60*60*24-$months*30*60*60*24)/(60*60*24)); 
$hours = floor(($diff-$years*365*60*60*24-$months*30*60*60*24-$days*60*60*24)/(60*60));   
$minutes = floor(($diff-$years*365*60*60*24-$months*30*60*60*24-$days*60*60*24-$hours*60*60)/60);
$seconds = floor(($diff-$years*365*60*60*24-$months*30*60*60*24-$days*60*60*24-$hours*60*60-$minutes*60)); 
$Posted = ""; 
if($years>0)
{
  $SingularPlural = SingularPlural($years);
  $Posted.=$years." year".$SingularPlural;
}
else if($months>0)
{
  $SingularPlural = SingularPlural($months);
  $Posted.=$months." month".$SingularPlural;
}
else if($days>0)
{
  $SingularPlural = SingularPlural($days);
  $Posted.=$days." day".$SingularPlural;
}
else if($hours>0)
{
  $SingularPlural = SingularPlural($hours);
  $Posted.=$hours." hour".$SingularPlural;
}
else if($minutes>0)
{
  $SingularPlural = SingularPlural($minutes);
  $Posted.=$minutes." minute".$SingularPlural;
}
else if($seconds>0)
{
  $SingularPlural = SingularPlural($seconds);
  $Posted.=$seconds." second".$SingularPlural;
} 
?>
              <div class="post-ftr-l">
                <div class="col-md-10 wg-rating">
                  <div class="leftpost-wg views-p">
                    <span>123 Views</span>
                  </div>
                  <div class="leftpost-wg upvote-p">
                    <a href="javascript:" class="ProductUpvote" ProductId="{{ $Product->id }}">
                      <img src="{{ asset('public/images/upvote.png') }}">
                      <span class="vc-t-p ProductUpvoteCount"> 
                        <?php
                        $ParaMeter = array(); 
                        $ParaMeter["ProductId"] = $Product->id;
                        echo App\ProductUpvote::CountProductUpvote($ParaMeter);
                        ?>
</span>
                    </a>
                  </div>
                  <div class="leftpost-wg reshare-p">
                    <a href="{{ route('ProductReshare',['ProductId'=>$Product->id]) }}">
                    <i class="fa fa-refresh" aria-hidden="true"></i>
                    <span class="vc-t-p">{{ $Product->reshare_count }}</span>
                    </a>
                  </div>
                  <div class="leftpost-wg reshare-p">
                    <?php
                      $ParaMeter = array(); 
                      $ParaMeter["ProductLikesCountId"] = $Product->id;
                      $GetProductLikes = App\ProductLike::GetProductLikes($ParaMeter);
                    ?>
                    <a id="CreatePaidAdLike" class="CreatePaidAdLike" ProductId="{{ $Product->id }}">
                      <span>
                        <i class="fa fa-thumbs-o-up" aria-hidden="true"></i>
                      </span>
                      <span id="ProductLikeCount">
                        @if(!$GetProductLikes->isEmpty())
                        {{ $GetProductLikes[0]->ProductLikesCount }}
                        @endif
                      </span>
                    </a>
                  </div>
                  <div class="leftpost-wg reshare-p">
                    <a href="#">
                      <span><i class="fa fa-comments-o" aria-hidden="true"></i></span><span id="ProductCommentCount">{{ $GetProductComments->count() }}</span>
                    </a>
                  </div>


                  <div class="leftpost-wg post-day"><span class="vc-t-p">Posted {{ $Posted }} ago</span></div>
                </div>
                <div class="col-md-2 link-s-v">
                  <div class="rightpost-wg">
                    <div class="two-btn-right">
                          <div class="share-left">
                            <div class="dropdown">
                              <button class="btn btn-primary dropdown-toggle btn-all-tran" type="button" data-toggle="dropdown"><i class="fa fa-share-alt" aria-hidden="true"></i></button>
                              <ul class="dropdown-menu">
                                <li><a href="#"><span><i class="fa fa-facebook-square" aria-hidden="true"></i></span> Facebook</a></li>
                                <li><a href="#"><span><i class="fa fa-twitter-square" aria-hidden="true"></i></span> Twitter</a></li>
                                <li><a href="#">Copy Post Link</a></li>
                              </ul>
                            </div>
                          </div>
                          <div class="post-r-right">
                            <div class="dropdown">
                              <button class="btn btn-primary dropdown-toggle btn-all-tran" type="button" data-toggle="dropdown"><i class="fa fa-ellipsis-h" aria-hidden="true"></i></button>
                              <ul class="dropdown-menu">
                                <li><a href="#"><span><i class="fa fa-times" aria-hidden="true"></i></span> Remove Post</a></li>
                                <li><a href="#"><span><i class="fa fa-ban" aria-hidden="true"></i></span>Ban User for 14 Days</a></li>
                                <li><a href="#"><span><i class="fa fa-lightbulb-o" aria-hidden="true"></i></span>Suggest Edits for Post</a></li>
                              </ul>
                            </div>
                          </div>
                        </div>
                    <!-- <span class="dot-sign"><i class="fa fa-ellipsis-h" aria-hidden="true"></i></span> -->
                  </div>
                </div>
              </div>
            </div>
            @endforeach
            <div class="views-more text-center"><button type="button" class="view-btn-more" id="ViewMoreProduct"  Page="{{ $Page }}">View More</button></div>
          @else
            {{ 'Currentlly No Item For Sale Found' }}
          @endif