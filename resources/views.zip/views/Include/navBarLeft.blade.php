<div id="wrapper">
<div id="page-content-wrapper">
<div id="sidebar-wrapper">
<div class="sidenav">
    <ul class="left-sede-navbar">
        <li class="active_tabe"><a href="{{ route('AdminHome') }}"><i class="fa fa-home fa-fw"></i>Home</a></li>
        <li><a href="{{ route('ShopList') }}"><i class="fa fa-shop"></i>Shop List</a></li>
        <li><a href="{{ route('BannerList') }}"><i class="fa fa-shop"></i>Banner List</a></li>
        <li><a href="{{ route('ClaimToRemovePostList') }}"><i class="fa fa-shop"></i>Claim To Remove Post</a></li>
        <li><a href="{{ route('ReportPictureAsYourList') }}"><i class="fa fa-shop"></i>Report Picture As Your</a></li>
    </ul>
</div>
</div>