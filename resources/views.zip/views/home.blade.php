@extends('layouts.Frontend')
@section('content')
<?php
//die();
?>
@if(Auth::check())
<script type="text/javascript">
  var ProductAddModalAjax = "{{ route('ProductAddModalAjax') }}"; //Product Add Modal Ajax Path Url
  var ClaimToRemovePostAjax = "{{ route('ClaimToRemovePostAjax') }}"; //Claim To Remove Post Ajax Path Url
  var ReportPictureAsYourAjax = "{{ route('ReportPictureAsYourAjax') }}"; //Report Picture As Your Ajax Path Url
</script>
@endif
<script type="text/javascript">
  var ProductDetailsModalAjax = "{{ route('ProductDetailsModalAjax') }}"; //Product Details Modal Ajax Path Url
  var RecentProductDetailsListAjax = "{{ route('RecentProductDetailsListAjax') }}"; //Recent Product Details List Ajax Path Url
  var ImagesSliderPopupAjax = "{{ route('ImagesSliderPopupAjax') }}"; //Images Slider Popup Ajax Path Url
  var CreatePaidAdLikeAjax = "{{ route('CreatePaidAdLikeAjax') }}"; //Create Paid Ad Like Ajax Path Url
  var ProductCommentAddAjax = "{{ route('ProductCommentAddAjax') }}"; //Product Comment Ajax Path Url
  var ManageRequestAddAjax = "{{ route('ManageRequestAddAjax') }}"; //Manage Request Add Ajax Path Url
  var ProductUpvoteAjax = "{{ route('ProductUpvote') }}";  //Product Upvote ajax url path
</script>
<div class="banner-slider text-center">
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <!-- <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol> -->

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <!-- <div class="item active">
        <img src="{{ asset('public/images/slide1.jpg') }}" alt="Los Angeles" style="width:100%;">
      </div>
      <div class="item">
        <img src="{{ asset('public/images/slider2.jpg') }}" alt="Chicago" style="width:100%;">
      </div>
      <div class="item">
        <img src="{{ asset('public/images/slider3.jpg') }}" alt="Chicago" style="width:100%;">
      </div>
      <div class="item">
        <img src="{{ asset('public/images/slider4.jpg') }}" alt="Chicago" style="width:100%;">
      </div>
      <div class="item">
        <img src="{{ asset('public/images/slider5.jpg') }}" alt="Chicago" style="width:100%;">
      </div> -->
      @if(!$GetBannerImages->isEmpty())
        <?php $Active = 0; ?>
        @foreach($GetBannerImages as $BannerImage)
        <div class="item @if($Active==0) {{ 'active' }} @endif">
            <img src="{{ asset('public/images/banner_images/'.$BannerImage->banner_image) }}" style="width: 100%;">
        </div>
        <?php $Active++; ?>
        @endforeach
      @else
        <div class="item active">
          <img src="{{ asset('public/images/slide1.jpg') }}" style="width: 100%;">
        </div>
      @endif
    </div>

    <!-- Left and right controls -->
    @if($GetBannerImages->count()>=2)
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
    @endif
  </div>
</div>
<!-- <div class="banner text-center">
  @if(!$GetBannerImages->isEmpty())
    <img src="{{ asset('public/images/banner_images/'.$GetBannerImages[0]->banner_image) }}" style="width: 100%;">
  @else
    <img src="{{ asset('public/images/slide1.jpg') }}" style="width: 100%;">
  @endif
</div> -->
<?php
//echo "<pre>";
//print_r($GetBannerImages);
//die();
?>
    <section class="markert-section">   
    <div class="container"> 
      <div class="row">
        <div class="col-md-3 sticky-both" style="padding: 0px;">
          <div class="box-with-fl">
        
            
              
          
          <div class="events-p mb-2">
            <h3 class="title-events-1"><p>Events Near Indore India</p></h3>
            @if(!$GetAllEvents->isEmpty())
            @foreach($GetAllEvents as $Event)
            <div class="events-group">
              <p><img src="{{ asset('public/images/event_logo/'.$Event->event_logo) }}"></p>
              <div class="all-events">
                 <div class="events-date"><span><?php echo date("F",strtotime($Event->event_date)) ?></span><br><?php echo date("d",strtotime($Event->event_date)) ?></div>
                 <div class="title-events">
                  <h3>{{ $Event->event_name }}</h3>
                   <p><span>Today {{ $Event->event_time }}<span aria-hidden="true" role="presentation"> · </span>{{ $Event->event_address }}</span></p>
                   <!-- <div class="_7u2">4 people interested</div> -->
                </div>
              </div>
              <div class="disc-eve">
                <?php echo $Event->event_description; ?>
                <p>WhatsApp/Call : {{ $Event->event_mobile }}</p>
                <p><a href="#">website : {{ $Event->event_website }}</a></p>
              </div>
            </div>
            <span class="product-btn text-center"><a href="{{ route('EventAll') }}">View More</a></span>
            @endforeach
            @else
              {{ 'Currentlly No Event Found' }}
            @endif
          </div>
          <div class="events-p">
            <h3 class="title-events-1">Suggested Posts</h3>
            <div class="feed-post mb-0">
              <div id="suggested-post" class="carousel slide" data-ride="carousel" data-interval="2000">
                  <div class="carousel-inner">
                      <div class="item active">
                        <div class="sugestlink-other">
                          <a href="#">
                            <div class="leftside-suggested">
                              <div class="suggest-img mb-2">
                                <img src="{{ asset('public/images/product-1.jpg') }}">
                              </div>
                              <div class="postl-v">
                                <h3>Furniture Grey Colour by Looking Good</h3>
                                <div class="short-dics-post">
                                  <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a </p>
                                </div>
                                <span class="price-post">Ksh 250.00</span>
                              </div>
                            </div>
                          </a>
                        </div>
                      </div>
                      <div class="item">
                        <div class="sugestlink-other">
                          <a href="#">
                            <div class="leftside-suggested">
                              <div class="suggest-img mb-2">
                                <img src="{{ asset('public/images/electonic-1.jpg') }}">
                              </div>
                              <div class="postl-v">
                                <h3>Electronic Grey Colour by Looking Good</h3>
                                <div class="short-dics-post">
                                  <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a </p>
                                </div>
                                <span class="price-post">Ksh 250.00</span>
                              </div>
                            </div>
                          </a>
                        </div>
                      </div>
                  </div>
              </div>                                              
            </div>
          </div>
        </div>
        </div>
        <div class="col-md-6">
            
            @if(Session::has('message'))
            <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
            @endif
            <?php
            //die();
            if(Session::has('message'))
            {
              Session::flash('alert-class','');
              Session::flash('message', "");
            }
            ?>

            @if(Auth::check())
            <div class="share-post clearfix">
                <div class="text-write">
                    <span class="selin-tag-c">
                      <button type="button" class="btn" id="ProductAddModal" ProductId="">
                        <span class="sale-some-tag">
                          <img src="{{ asset('public/images/logo.png') }}">
                        </span>
                        Sell Something
                      </button>
                    </span>
                    <span class="selin-tag-c">
                      <a href="{{ route('EventAdd') }}">
                        <button type="button" class="btn">
                          <span class="sale-some-tag">
                            <i class="fa fa-calendar" aria-hidden="true"></i>
                          </span>
                          Create Event
                        </button>
                      </a>
                    </span>
                </div>
                <div class="selling-p">
                    <h4>What are you selling?</h4>
                </div>
            </div>
            @endif
            <div class="feed-post">
              <div class="post-f-box">
                <div class="title-heading">
                  <h3><span><i class="fa fa-bullhorn" aria-hidden="true"></i></span><strong>Announcement</strong></h3>
                  <div class="see-all">
                    <a href="{{ route('Announcement') }}">
                      <span class="see-txt">See all ({{ $GetAnnouncementCreatePaidAdCount }})</span>
                    </a>
                  </div>
                </div>
                @if(!$GetAnnouncementCreatePaidAd->isEmpty())
                  @foreach($GetAnnouncementCreatePaidAd as $Product)
                <div class="Announce-box-w">
                  <div class="post-img-s">
                    <img src="{{ asset('public/images/product_images/'.$Product->product_image_name) }}">
                  </div>
                  <div class="post-cont-f">
                    <h5>{{ $Product->product_name }}</h5>
                  </div>
                </div>
                <div class="likes-user ProductLikeUsersParent">
                  <div class="other-user-l">
                    <span class="like-btn"><i class="fa fa-thumbs-up" aria-hidden="true"></i></span>
                    <span class="whislist-btn"><i class="fa fa-heart" aria-hidden="true"></i></span>
                    <span class="name-point ProductLikeUsers" id="ProductLikeUsers">
                      
                      <?php
                      $ParaMeter = array();
                  $ParaMeter["ProductId"] = $Product->id;
                  $ProductLikeUsers = App\ProductLike::GetProductLikes($ParaMeter);

                $LikeMessage1 = '<ul class="name-point tooltips-open" id="ProductLikeUserLists" >';
                  if(!$ProductLikeUsers->isEmpty())
                  {
                    $ProductLikeUsersArray = explode(",", $ProductLikeUsers[0]->ProductLikeUsers);
                    $ProductLikeUsersIdArray = explode(",", $ProductLikeUsers[0]->ProductLikeUsersId);
                    $ProductLikeUserCount = count($ProductLikeUsersArray);
                    $ProductLikeUserIdCount = count($ProductLikeUsersIdArray);
                    
                    if($ProductLikeUserCount>2 && $ProductLikeUserIdCount>2 && $ProductLikeUserCount==$ProductLikeUserIdCount)
                    {
                  
                      for ($i=0; $i < $ProductLikeUserCount; $i++) 
                      { 
                        if($i!=0)
                        {
                          //echo " , ";
                          //$LikeMessage1 .= "<br/>";
                        }
                        $VendorName = str_replace(' ', '-', $ProductLikeUsersArray[$i]);
                        $LikeMessage1 .= "<li><a href='".route('Myprofile',['VendorName'=>$VendorName,'VendorId'=>$ProductLikeUsersIdArray[$i]])."'>".$ProductLikeUsersArray[$i]."</a></li>";
                        $LikeMessage1 .=  " ";
                      }
                    }
                    else
                    {
                      $VendorName = str_replace(' ', '-', $ProductLikeUsers[0]->ProductLikeUsers);
                      $LikeMessage1 .="<a href='".route('Myprofile',['VendorName'=>$VendorName,'VendorId'=>$ProductLikeUsers[0]->ProductLikeUsersId])."'>".$ProductLikeUsers[0]->ProductLikeUsers."</a>"; 
                    }
                  }
                  $LikeMessage1 .="</ul>";
                  ?>


                  <?php 
                  
                  if(!$ProductLikeUsers->isEmpty())
                  {
                    $ProductLikeUsersArray = explode(",", $ProductLikeUsers[0]->ProductLikeUsers);
                    $ProductLikeUsersIdArray = explode(",", $ProductLikeUsers[0]->ProductLikeUsersId);
                    $ProductLikeUserCount = count($ProductLikeUsersArray);
                    $ProductLikeUserIdCount = count($ProductLikeUsersIdArray);
                    
                    if($ProductLikeUserCount>2 && $ProductLikeUserIdCount>2 && $ProductLikeUserCount==$ProductLikeUserIdCount)
                    {
                      $LikeMessage = "";
                      for ($i=0; $i < $ProductLikeUserCount; $i++) 
                      { 
                        if($i==2)
                        {
                          break;
                        }
                        if($i!=0)
                        {
                          //echo " , ";
                          $LikeMessage .= " , ";
                        }
                        $VendorName = str_replace(' ', '-', $ProductLikeUsersArray[$i]);
                        $LikeMessage .= "<a href='".route('Myprofile',['VendorName'=>$VendorName,'VendorId'=>$ProductLikeUsersIdArray[$i]])."'>".$ProductLikeUsersArray[$i]."</a>";
                        $LikeMessage .=  " ";
                      }
                      $LikeMessage2 =  "";
                      if($ProductLikeUserCount!=3)
                      {
                        $LikeMessage2 =  "s";
                      }
                      $LikeMessage .=  $ProductLikeUserCount-2;
                      $LikeMessage .=  " <span class='name-point tooltip top'>other".$LikeMessage2.$LikeMessage1."</span>";
                      
                      echo $LikeMessage;
                    }
                    else
                    {
                      $VendorName = str_replace(' ', '-', $ProductLikeUsers[0]->ProductLikeUsers);
                      echo "<a href='".route('Myprofile',['VendorName'=>$VendorName,'VendorId'=>$ProductLikeUsers[0]->ProductLikeUsersId])."'>".$ProductLikeUsers[0]->ProductLikeUsers."</a>"; 
                    }
                  }
                  ?>
              </span>
                    
                    <!-- Atul Mishra,Pankaj Kapoor and 5 others -->
                  </div>
                  <div class="like-coment-fill clearfix">
                    <ul class="bottom-likes clearfix">
                      <li>
                        <a id="CreatePaidAdLike" class="CreatePaidAdLike" ProductId="{{ $Product->id }}" ProductId="{{ $Product->id }}">
                          <span>
                            <i class="fa fa-thumbs-o-up" aria-hidden="true"></i>
                          </span>
                          Like
                        </a>
                      </li>
                      <?php
                      //$ParaMeter["Limit"] = 3;
                      $GetProductComments = App\ProductComment::GetProductComments($ParaMeter);
                      ?>
                      <li><a href="#"><span><i class="fa fa-comments-o" aria-hidden="true"></i></span> 
                      <span id="ProductCommentCount"><?php echo count($GetProductComments); ?></span> Comment</a></li>
                      <li class="two-pro-p">
                        <div class="two-btn-right">
                          <div class="share-left">
                            <div class="dropdown">
                              <button class="btn btn-primary dropdown-toggle btn-all-tran" type="button" data-toggle="dropdown"><i class="fa fa-share-alt" aria-hidden="true"></i></button>
                              <ul class="dropdown-menu">
                                <li><a href="#"><span><i class="fa fa-facebook-square" aria-hidden="true"></i></span> Facebook</a></li>
                                <li><a href="#"><span><i class="fa fa-twitter-square" aria-hidden="true"></i></span> Twitter</a></li>
                                <li><a href="#">Copy Post Link</a></li>
                              </ul>
                            </div>
                          </div>
                          <div class="post-r-right">
                            <div class="dropdown">
                              <button class="btn btn-primary dropdown-toggle btn-all-tran" type="button" data-toggle="dropdown"><i class="fa fa-ellipsis-h" aria-hidden="true"></i></button>
                              <ul class="dropdown-menu">
                                <li><a href="#"><span><i class="fa fa-times" aria-hidden="true"></i></span> Remove Post</a></li>
                                <li><a href="#"><span><i class="fa fa-ban" aria-hidden="true"></i></span>Ban User for 14 Days</a></li>
                                <li><a href="#"><span><i class="fa fa-lightbulb-o" aria-hidden="true"></i></span>Suggest Edits for Post</a></li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </li>
                      <!-- <li><a href="#"><span><i class="fa fa-share-alt" aria-hidden="true"></i></span>Share</a></li>
                      <li class="dropright dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span><i class="fa fa-caret-down" aria-hidden="true"></i></span></a>
                        <ul class="dropdown-menu">
                          <li><a href="#">Demo</a></li>
                        </ul>
                      </li> -->
                    </ul>
                  </div>
               
                </div>
                @endforeach
                @endif
              </div>
            </div>
          <!--   <div class="full-product-veiw clearfix">
              <div class="clearfix">
                <div class="col-md-12">
                  <div class="title-heading mb-2">
                    <h3>Item For Sale</h3>
                    <div class="see-all">
                      <span class="see-txt">See all 1,230,895 item for sale</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-12 row-full-sec" style="padding-top: 0px;">
                @if(!$RecentProductList->isEmpty())
                  @foreach($RecentProductList as $Product)
                  <div class="col-md-4 product-padd">
                    <div class="product-item-11 ProductDetailsModal" id="{{ $Product->id }}">
                      <span class="productmodal">
                        <img src="{{ asset('public/images/product_images/'.$Product->product_image_name) }}">
                        <div class="price-t"><span>$ {{  $Product->product_price }}</span></div>
                      </span>
                    </div>
                  </div>
                  @endforeach
                @else
                  {{ 'Currentlly No Item For Sale Found' }}
                @endif
              </div>
              <div class="clearfix post--item-vc" id="RecentProductDetailsListItemForSale">
              </div>
            </div> -->
            <div class="clearfix post--item-vc" id="RecentProductDetailsList">
              <!----end-1--->
            </div>
        </div> <!-- col-md-6 -->
        <div class="col-md-3 sticky-both" style="padding-left: 0px;padding-right: 0px;">
          <div class="produc-box-slide mb-2">
            <h3 class="title-events-1">Sponsored Shops</h3>
            <div class="product-side-mark">
              <div id="viewproduct" class="carousel slide" data-ride="carousel" data-interval="2000">
              <!-- Indicators 
              <ol class="carousel-indicators">
                <li data-target="#viewproduct" data-slide-to="0" class="active"></li>
                <li data-target="#viewproduct" data-slide-to="1"></li>
                <li data-target="#viewproduct" data-slide-to="2"></li>
              </ol>-->

              <!-- Wrapper for slides -->
              <div class="carousel-inner">
                @if(!$GetAllVendors->isEmpty())
                  <?php $i=1; ?>
                  @foreach($GetAllVendors as $Vendor)
                    <div class="item @if($i==1) {{ 'active' }} @endif">
                       <?php 
                          $BusinessLogo = url('public/images/user_default_pic.jpg');
                       ?>
                       @if($Vendor->business_logo!="" && file_exists(public_path().'/images/business_logo/'.$Vendor->business_logo))         
                        <?php 
                          $BusinessLogo = url('public/images/business_logo/'.$Vendor->business_logo);
                        ?>
                       @endif
                      <img src="{{ $BusinessLogo }}">
                    <div class="product-app-disc">
                      <h3>{{ $Vendor->name }} </h3>
                      <span class="location-app"><i class="fa fa-map-marker" aria-hidden="true"></i> London</span>
                      <?php
                        $VendorName = str_replace(' ', '-', $Vendor->name);
                      ?>
                      <span class="product-btn"><a href="{{ route('ProductManage',['VendorName'=>$VendorName,'VendorId'=>$Vendor->id]) }}">Veiw Product</a></span>
                    </div>
                  </div>
                  <?php $i++; ?> 
                  @endforeach
                @else
                  {{ 'Currentlly No Vendors Found' }}
                @endif
                <!-- <div class="item active">
                  <img src="{{ asset('public/images/product-8.jpg') }}">
                    <div class="product-app-disc">
                      <h3>New Pouch Set Marketing </h3>
                      <span class="location-app"><i class="fa fa-map-marker" aria-hidden="true"></i> London</span>
                      <span class="product-btn"><a href="product.html">Veiw Product</a></span>
                    </div>
                </div>
                <div class="item">
                  <img src="{{ asset('public/images/product-9.jpg') }}">
                    <div class="product-app-disc">
                      <h3>New Pouch Set Marketing </h3>
                      <span class="location-app"><i class="fa fa-map-marker" aria-hidden="true"></i> London</span>
                      <span class="product-btn"><a href="product.html">Veiw Product</a></span>
                    </div>
                </div>
                <div class="item">
                  <img src="{{ asset('public/images/product-2.jpg') }}">
                    <div class="product-app-disc">
                      <h3>New Pouch Set Marketing </h3>
                      <span class="location-app"><i class="fa fa-map-marker" aria-hidden="true"></i> London</span>
                      <span class="product-btn"><a href="product.html">Veiw Product</a></span>
                    </div>
                <div class="item">
                  <img src="{{ asset('public/images/product-6.jpg') }}">
                </div>
                    <div class="product-app-disc">
                      <h3>New Pouch Set Marketing </h3>
                      <span class="location-app"><i class="fa fa-map-marker" aria-hidden="true"></i> London</span>
                      <span class="product-btn"><a href="product.html">Veiw Product</a></span>
                    </div>
                </div>
              </div> -->

              <!-- Left and right controls 
              <a class="left carousel-control" href="#viewproduct" data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left"></span>
                <span class="sr-only">Previous</span>
              </a>
              <a class="right carousel-control" href="#viewproduct" data-slide="next">
                <span class="glyphicon glyphicon-chevron-right"></span>
                <span class="sr-only">Next</span>
              </a>-->
            </div>
          </div>
        </div>
      </div>
      <div class="produc-box-slide">
          <h3 class="title-events-1">Shops Near You</h3>
          <div class="product-side-mark">
            <div id="shopa-new" class="carousel slide" data-ride="carousel" data-interval="3000">
            <!-- Indicators 
            <ol class="carousel-indicators">
              <li data-target="#viewproduct" data-slide-to="0" class="active"></li>
              <li data-target="#viewproduct" data-slide-to="1"></li>
              <li data-target="#viewproduct" data-slide-to="2"></li>
            </ol>-->

            <!-- Wrapper for slides -->
            <div class="carousel-inner">
              <div class="item active">
                <img src="{{ asset('public/images/cloths-1.jpg') }}">
                  <div class="product-app-disc">
                    <h3>New Pouch Set Marketing </h3>
                    <span class="location-app"><i class="fa fa-map-marker" aria-hidden="true"></i> London</span>
                    <span class="product-btn"><a href="product.html">Veiw Product</a></span>
                  </div>
              </div>
              <div class="item">
                <img src="{{ asset('public/images/electonic-1.jpg') }}">
                  <div class="product-app-disc">
                    <h3>New Pouch Set Marketing </h3>
                    <span class="location-app"><i class="fa fa-map-marker" aria-hidden="true"></i> London</span>
                    <span class="product-btn"><a href="product.html">Veiw Product</a></span>
                  </div>
              </div>
              <div class="item">
                <img src="{{ asset('public/images/home-1.jpg') }}">
                  <div class="product-app-disc">
                    <h3>New Pouch Set Marketing </h3>
                    <span class="location-app"><i class="fa fa-map-marker" aria-hidden="true"></i> London</span>
                    <span class="product-btn"><a href="product.html">Veiw Product</a></span>
                  </div>
              </div>
              <div class="item">
                <img src="{{ asset('public/images/product-1.jpg') }}">
                  <div class="product-app-disc">
                    <h3>New Pouch Set Marketing </h3>
                    <span class="location-app"><i class="fa fa-map-marker" aria-hidden="true"></i> London</span>
                    <span class="product-btn"><a href="product.html">Veiw Product</a></span>
                  </div>
              </div>
            </div>

            <!-- Left and right controls 
            <a class="left carousel-control" href="#viewproduct" data-slide="prev">
              <span class="glyphicon glyphicon-chevron-left"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#viewproduct" data-slide="next">
              <span class="glyphicon glyphicon-chevron-right"></span>
              <span class="sr-only">Next</span>
            </a>-->
          </div>
        </div>
      </div>
      </div>
    </div>
    <div class="row">
      <div class="col-xs-12 text-center">
        <div class="advert-banner"><img src="{{ asset('public/images/advertise.jpg') }}"></div>
      </div>
    </div>
  </div>
</section>
<!-- Product Add Modal Start -->
<div class="modal fade" id="salesomthing" role="dialog">
</div>
<!------ Product Add Modal End --->

<!-- Product Details Modal Start -->
<div id="ProductDetailsModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content" id="ProductDetailsModalBody">
    </div>
  </div>
</div>
<!-- Product Details Modal End -->

<!-- Slider Popup Modal Start -->
<div id="sliderpopup" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-close">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body" style="padding: 0px;" id="SliderPopupImages">
        <div class="contactno"><span class="contact-no-post">
                    +{{ $Product->product_phone }}</span><span class="contact-no-post">Ksh {{ $Product->product_price }}/-</span></div>
      </div>
    </div>
  </div>
</div>
<!-- Slider Popup Modal End -->
<script src="{{ asset('public/js/Frontend.js') }}"></script>
@if(Auth::check())
<script src="{{ asset('public/js/Backend.js') }}"></script>
<script src="{{ asset('public/js/AddMoreProducts.js') }}"></script>
@endif
@if(Auth::check() && Auth()->user()->user_type==1)
<script type="text/javascript">
function DeleteTest()
{
  if(confirm("Are You Sure You Want To Delete This?"))
  {
  }
  else
  {
    return false;
  }
}
</script>
@endif
@endsection